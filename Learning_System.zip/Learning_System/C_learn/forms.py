from typing import Any
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm
# from captcha.fields import ReCaptchaField
# from captcha.widgets import ReCaptchaV2Checkbox
from django.contrib.auth.forms import SetPasswordForm, PasswordResetForm
from django.contrib.auth.forms import PasswordResetForm

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(help_text='A valid Email Please', required=True)

    class Meta:
        model = get_user_model()
        fields = ['first_name', 'last_name', 'username', 'email', 'password1', 'password2']

    def save(self, commit= True):
        user =super(UserRegistrationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user
    
class UserLoginForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super(UserLoginForm, self).__init__( *args, **kwargs)
    
    username = forms.CharField(widget=forms.TextInput(
        attrs = {'class': 'form-control', 'placeholder': 'Username or email'}),
        label='Username or Email*')
    
    password = forms.CharField(widget=forms.PasswordInput(
        attrs={'class': 'form-control', 'placeholder': 'password'}
    ))
    # captcha = ReCaptchaField(widget = ReCaptchaV2Checkbox)

class SetPasswordForm(SetPasswordForm):
    class Meta:
        model = get_user_model()
        fields = ['new_password1', 'new_password2']

# class PasswordResetForm(PasswordResetForm):
#     def __int__(self, *args, **kwargs):
#         super(PasswordResetForm, self).__init__(*args, **kwargs)
#     captcha = ReCaptchaField(widget= ReCaptchaV2Checkbox())
class PasswordResetForm(PasswordResetForm):
    def __init__(self, *args, **kwargs):
        super(PasswordResetForm, self).__init__(*args, **kwargs)

    # captcha = ReCaptchaField(widget=ReCaptchaV2Checkbox())


class UserUpdateForm(forms.ModelForm):
    email = forms.EmailField()
    class Meta:
        model = get_user_model()
        fields =['first_name', 'last_name', 'email', 'description']